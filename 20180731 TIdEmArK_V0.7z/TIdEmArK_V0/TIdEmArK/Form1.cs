﻿
using Siemens.Engineering;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Features;
using Siemens.Engineering.HW.Utilities;
using Siemens.Engineering.SW;
using Siemens.Engineering.SW.Blocks;
using Siemens.Engineering.SW.TechnologicalObjects;
using Siemens.Engineering.SW.TechnologicalObjects.Motion;
using Siemens.Engineering.SW.ExternalSources;
using Siemens.Engineering.SW.Tags;
using Siemens.Engineering.SW.Types;
using Siemens.Engineering.Hmi;
using Siemens.Engineering.Hmi.Tag;
using Siemens.Engineering.Hmi.Screen;
using Siemens.Engineering.Hmi.Cycle;
using Siemens.Engineering.Hmi.Communication;
using Siemens.Engineering.Hmi.Globalization;
using Siemens.Engineering.Hmi.TextGraphicList;
using Siemens.Engineering.Hmi.RuntimeScripting;
using System.Collections.Generic;
using Siemens.Engineering.Online;
using Siemens.Engineering.Compiler;
using Siemens.Engineering.Library;
using Siemens.Engineering.Library.Types;
using Siemens.Engineering.Library.MasterCopies;
using Siemens.Engineering.Compare;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.ComponentModel;
using System.Linq;
using System.Security;
using System.Xml.Linq;
using Siemens.Engineering.Connection;
using Siemens.Engineering.Download;
using Siemens.Engineering.Download.Configurations;











namespace TIdEmArK
{
    public partial class Form1 : Form
    {

        //Variablen für neues Projekt anlegen
        string TiaProjectPath;
        string TiaProjectName;
        private static TiaPortalProcess _tiaProcess;
        public TiaPortal MyTiaPortal
        {
            get; set;
        }
        public Project MyProject
        {
            get; set;
        }
        public Device MyDevice
        {
            get; set;
        }
        public DeviceGroup MyDeviceGroup1
        {
            get; set;
        }

        public Form1()
        {
            InitializeComponent();
            AppDomain CurrentDomain = AppDomain.CurrentDomain;
            CurrentDomain.AssemblyResolve += new ResolveEventHandler(MyResolver);
            this.AutoSize = true;
            //this.AutoSizeMode = AutoSizeMode.GrowAndShrink;

        }
        private static Assembly MyResolver(object sender, ResolveEventArgs args)
        {
            int index = args.Name.IndexOf(',');
            if (index == -1)
            {
                return null;
            }
            string name = args.Name.Substring(0, index);

            Microsoft.Win32.RegistryKey filePathReg = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                "SOFTWARE\\Siemens\\Automation\\Openness\\15.0\\PublicAPI\\15.0.0.0");

            if (filePathReg == null)
                return null;

            object oRegKeyValue = filePathReg.GetValue(name);
            if (oRegKeyValue != null)
            {
                string filePath = oRegKeyValue.ToString();

                string path = filePath;
                string fullPath = Path.GetFullPath(path);
                if (File.Exists(fullPath))
                {
                    return Assembly.LoadFrom(fullPath);
                }
            }

            return null;
        }

        //Oberflächenprogrammierung in Windows Form
        #region TIA START
        private void btn_StartTIA_Click(object sender, EventArgs e)
        {
            if (rdb_WithoutUI.Checked == true)
            {
                MyTiaPortal = new TiaPortal(TiaPortalMode.WithoutUserInterface);
                txt_Status.Text = "TIA Portal started without user interface";
                _tiaProcess = TiaPortal.GetProcesses()[0];
            }
            else
            {
                MyTiaPortal = new TiaPortal(TiaPortalMode.WithUserInterface);
                txt_Status.Text = "TIA Portal started with user interface";
            }
            Console.WriteLine("Hallo Welt!");
            btn_SearchProject.Enabled = true;
            btn_disposeTIA.Enabled = true;
            btn_startTIA.Enabled = false;
            btn_NewProject.Enabled = true;
            txt_ProjectName.Enabled = true;
            txt_ProjectPath.Enabled = true;
        }
        #endregion

        #region TIA Dispose
        private void btn_disposeTIA_Click(object sender, EventArgs e)
        {
            MyTiaPortal.Dispose();
            txt_Status.Text = "TIA Portal disposed";
            btn_startTIA.Enabled = true;
            btn_disposeTIA.Enabled = false;
            btn_CloseProject.Enabled = false;
            btn_SearchProject.Enabled = false;
            btn_CompileHW.Enabled = false;
            btn_Save.Enabled = false;
            btn_NewProject.Enabled = false;
            txt_ProjectName.Enabled = false;
            txt_ProjectPath.Enabled = false;

        }
        #endregion

        #region TIA neues Projekt anlegen
        private void txt_ProjectPath_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                string ProjectSavePath = folderBrowserDialog1.SelectedPath.ToString();
                string ProjectSaveName = txt_ProjectName.Text;

                txt_ProjectPath.Text = ProjectSavePath;
                TiaProjectPath = ProjectSavePath;
                TiaProjectName = ProjectSaveName;
                btn_NewProject.Enabled = true;
            }
        }
        private void btn_NewProject_Click(object sender, EventArgs e)
        {
            //TiaPortal tiaPortal = new TiaPortal();
            ProjectComposition projectComposition = MyTiaPortal.Projects;
            DirectoryInfo targetDirectory = new DirectoryInfo(TiaProjectPath);
            Project project = projectComposition.Create(targetDirectory, TiaProjectName);

            txt_Status.Text = "New Project generated";
        }
        #endregion

        #region TIA Projekt öffnen
        //Projekt öffnen (1) Projektpfad sowie Projekt ermitteln
        private void btn_SearchProject_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileSearch = new OpenFileDialog();

            fileSearch.Filter = "*.ap15|*.ap15";
            fileSearch.RestoreDirectory = true;
            fileSearch.ShowDialog();

            string ProjectPath = fileSearch.FileName.ToString();

            if (string.IsNullOrEmpty(ProjectPath) == false)
            {
                OpenProject(ProjectPath);
            }
        }
        //Projekt öffnen (2) Projektpfad als Übergabewert von SearchProject() -> Projectpath
        private void OpenProject(string ProjectPath)
        {
            try
            {
                MyProject = MyTiaPortal.Projects.Open(new FileInfo(ProjectPath));
                txt_Status.Text = "Project " + ProjectPath + " opened";

            }
            catch (Exception ex)
            {
                txt_Status.Text = "Error while opening project" + ex.Message;
            }

            GenerateTreeView();
            btn_CompileHW.Enabled = true;
            btn_CloseProject.Enabled = true;
            btn_SearchProject.Enabled = false;
            btn_Save.Enabled = true;
            btn_AddHW.Enabled = true;

        }
        #endregion

        #region TIA Projekt speichern
        private void SaveProject(object sender, EventArgs e)
        {
            MyProject.Save();
            txt_Status.Text = "Project saved";
        }
        #endregion

        #region TIA Projekt schließen
        private void CloseProject(object sender, EventArgs e)
        {
            MyProject.Close();

            txt_Status.Text = "Project closed";

            btn_SearchProject.Enabled = true;
            btn_CloseProject.Enabled = false;
            btn_Save.Enabled = false;
            btn_CompileHW.Enabled = false;

        }
        #endregion

        #region TIA Baustein exportieren (bisher ungenutzt)
        //Exports a regular block
        private static void ExportRegularBlock(PlcSoftware plcSoftware)
        {
            PlcBlock plcBlock = plcSoftware.BlockGroup.Blocks.Find("TestFC1");
            plcBlock.Export(new FileInfo(string.Format(@"D:\Samples\{0}.xml", plcBlock.Name)), ExportOptions.WithDefaults);
        }
        #endregion

        #region TIA Connect zu offenem Projekt
        //Mit geöffnetem Projekt verbinden
        private void btn_Connect_Click(object sender, EventArgs e)
        {
            btn_Connect.Enabled = false;
            IList<TiaPortalProcess> processes = TiaPortal.GetProcesses();
            switch (processes.Count)
            {
                case 1:
                    _tiaProcess = processes[0];
                    MyTiaPortal = _tiaProcess.Attach();
                    if (MyTiaPortal.GetCurrentProcess().Mode == TiaPortalMode.WithUserInterface)
                    {
                        rdb_WithUI.Checked = true;
                    }
                    else
                    {
                        rdb_WithoutUI.Checked = true;
                    }


                    if (MyTiaPortal.Projects.Count <= 0)
                    {
                        txt_Status.Text = "No TIA Portal Project was found!";
                        btn_Connect.Enabled = true;
                        return;
                    }
                    MyProject = MyTiaPortal.Projects[0];
                    GenerateTreeView();


                    break;
                case 0:
                    txt_Status.Text = "No running instance of TIA Portal was found!";
                    btn_Connect.Enabled = true;
                    return;
                default:
                    txt_Status.Text = "More than one running instance of TIA Portal was found!";
                    btn_Connect.Enabled = true;
                    return;
            }
            txt_Status.Text = _tiaProcess.ProjectPath.ToString();
            btn_startTIA.Enabled = false;
            btn_Connect.Enabled = true;
            btn_disposeTIA.Enabled = true;
            btn_CompileHW.Enabled = true;
            btn_CloseProject.Enabled = true;
            btn_SearchProject.Enabled = false;
            btn_Save.Enabled = true;
            btn_AddHW.Enabled = true;
        }
        #endregion

        #region TIA Hardware per Hand hinzufügen
        private void btn_AddHW_Click(object sender, EventArgs e)
        {
            btn_AddHW.Enabled = false;
            string MLFB = "OrderNumber:" + txt_OrderNo.Text + "/" + txt_Version.Text;

            string name = txt_AddDevice.Text;
            string devname = "station" + txt_AddDevice.Text;
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    if (deviceItem.Name == devname || device.Name == devname)
                    {
                        SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                        if (softwareContainer != null)
                        {
                            if (softwareContainer.Software is PlcSoftware)
                            {
                                PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                                if (controllerTarget != null)
                                {
                                    found = true;

                                }
                            }
                            if (softwareContainer.Software is HmiTarget)
                            {
                                HmiTarget hmitarget = softwareContainer.Software as HmiTarget;
                                if (hmitarget != null)
                                {
                                    found = true;

                                }

                            }
                        }
                    }
                }
            }
            if (found == true)
            {
                txt_Status.Text = "Device " + txt_Device.Text + " already exists";
            }
            else
            {
                Device deviceName = MyProject.Devices.CreateWithItem(MLFB, name, devname);

                txt_Status.Text = "Add Device Name: " + name + " with Order Number: " + txt_OrderNo.Text + " and Firmware Version: " + txt_Version.Text;
            }

            btn_AddHW.Enabled = true;
            GenerateTreeView();
        }





        #endregion

        #region TIA Hierarchie importieren
        private void EnumerateDevicesInProject(Project project, TreeView tv_object)
        {
            tv_ProjectTIA1.Nodes.Add("Project:" + project.Name); // Projekt Node anlegen
            tv_ProjectTIA1.Nodes[0].Checked = false;
            int count = 0;
            var devices = MyProject.Devices;
            foreach (Device device in devices)
            {
                tv_object.Nodes[0].Nodes.Add(device.Name);
                GenerateDeviceItems(device, tv_object, count);
                count = count + 1;

                ////Debug Test in Textdatei
                //string pfad = "C:\\Users\\benjamin.kross\\Desktop\\WriteLines.txt";
                //FileStream fs = new FileStream(pfad, FileMode.Append, FileAccess.Write);
                //StreamWriter sw = new StreamWriter(fs);
                //sw.WriteLine("zumindest steht hier was" + " " + device.Name + " " + device.IsGsd);                           
                //sw.Close();
                //fs.Close();
            }
        }
        private void GenerateDeviceItems(Device device, TreeView tv_object, int count)
        {
            foreach (var item in device.DeviceItems)
            {
                var deviceItem = (DeviceItem)item;
                tv_object.Nodes[0].Nodes[count].Nodes.Add(deviceItem.Name);
            }
        }
        #endregion

        #region TreeView aus TIA Hierarchie erzeugen
        public void GenerateTreeView()
        {
            tv_ProjectTIA1.Nodes.Clear();
            bool _currentProject;
            Program _statusproject = new Program();

            _currentProject = _statusproject.CurrentProject(_tiaProcess, MyTiaPortal, MyProject);

            if (_currentProject == true)
            {
                try
                {
                    EnumerateDevicesInProject(MyProject, tv_ProjectTIA1); // Geräte in Projekt enumerieren   
                    //tv_ProjectTIA1.ExpandAll(); //Subknoten aufklappen
                }
                catch
                {
                    txt_Status.Text = "Fehler! Anderes Projekt geöffnet.";
                    tv_ProjectTIA1.Enabled = false;
                }
                tv_ProjectTIA1.Enabled = true;
            }
        }
        #endregion

        #region TreeView aktualsieren
        private void refresh_Click(object sender, EventArgs e)
        {
            GenerateTreeView();
        }
        #endregion

        #region TIA Device im Projekt entfernen
        private void btn_deleteChkDev_Click(object sender, EventArgs e)
        {
            RemoveCheckedNodes(tv_ProjectTIA1.Nodes);
        }

        List<TreeNode> checkedNodes = new List<TreeNode>(); //Vorteil Liste -> man muss die Größe vorher nicht wissen

        void RemoveCheckedNodes(TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes)
            {
                if(node.Checked)
                {
                    checkedNodes.Add(node); //Markierte Knoten werden der Liste hinzugefügt
                }
                else
                {
                    RemoveCheckedNodes(node.Nodes); //Unterknoten mit einbeziehen
                }
            }
            foreach(TreeNode checkedNode in checkedNodes)
            {
                nodes.Remove(checkedNode); //Selektierte Knoten aus Liste checkNodes entfernen
            }
        }
        #endregion
    }
}
